import React from 'react'

const Home = () => {
  return (
   <header/>
  )
}

export default Home